create definer = rdsadmin@localhost trigger block_user_d
    before delete
    on user
    for each row
BEGIN
   IF old.User = 'rdsadmin' AND old.Host = 'localhost' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT DROP RDSADMIN USER';
   END IF;
   
   IF old.User = 'rdsrepladmin' THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT DROP RDSREPLADMIN USER';
   END IF;
END;

